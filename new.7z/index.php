<!DOCTYPE html>
<html>
<head>
<title>IT survey 2</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="styles.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

<div class="base">

    <div class="bg-img"></div>

        <div class="spacer10">
        </div>

    <div class="textarea">

        <div class="header">
            <div class="headertext">

                Frozenbyte IT survey 2020

            </div>
        </div>

        <div class="welcome">
            Welcome to the Frozenbyte IT survey. 
        </div>

        <div class="welcometext">
            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus auctor vitae, consectetuer et venenatis eget velit. Sed augue orci, lacinia eu tincidunt et eleifend nec lacus. Donec ultricies nisl ut felis, suspendisse potenti. Lorem ipsum ligula ut hendrerit mollis, ipsum erat vehicula risus, eu suscipit sem libero nec erat. Aliquam erat volutpat. Sed congue augue vitae neque. Nulla consectetuer porttitor pede. Fusce purus morbi tortor magna condimentum vel, placerat id blandit sit amet tortor.
        </div>

        <div class="spacer10">
        </div> 

        <hr class="hr1">

        <div class="formarea">

            <h2>1. System performance and stability</h2>
                <h3>1.1 Windows</h3>
                    <p>Windows startup takes too long</p>

                        <div class="disagree">
                            <input type="radio" name="windows1"
                            <?php if (isset($windows1) && $windows1=="false") print "checked";?> <font class="green">Disagree</font>
                        </div>

                        <div class="partlyagree">
                            <input type="radio" name="windows1"
                            <?php if (isset($windows1) && $windows1=="true") print "checked";?><font class="orange">Partly agree</font>
                        </div>

                        <div class="agree">
                            <input type="radio" name="windows1"
                            <?php if (isset($windows1) && $windows1=="true") print "checked";?><font class="red">Agree</font>
                        </div>

                    <br>
                        

                    <p>Windows updates often interrupt my work</p>

                        <div class="disagree">
                            <input type="radio" name="windows2"
                            <?php if (isset($windows2) && $windows2=="false") print "checked";?> <font class="green">Disagree</font>
                        </div>

                        <div class="partlyagree">
                            <input type="radio" name="windows2"
                            <?php if (isset($windows2) && $windows2=="true") print "checked";?><font class="orange">Partly agree</font>
                        </div>

                        <div class="agree">
                            <input type="radio" name="windows2"
                            <?php if (isset($windows2) && $windows2=="true") print "checked";?><font class="red">Agree</font>
                        </div>

                    <br>

                <h3>1.2 Software</h3>
                    <p>Programs take too long to start</p>

                    <p>Program performance is noticeably poor</p>

                    <p>Game or editor performance is poor</p>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
asd
        

        </div>

    </div>

</div>

</body>

</html>